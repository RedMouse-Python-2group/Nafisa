def exponent(x,y):
    return(x**y)