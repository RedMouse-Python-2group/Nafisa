def mult(x,y):
    return(x*y)