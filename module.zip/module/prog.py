def prog(x):
    z = 0
    while z < 10:
        x = x + 1
        z = z + 1
        print(x)